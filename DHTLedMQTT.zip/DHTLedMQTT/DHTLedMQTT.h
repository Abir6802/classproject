#ifndef DHTLedMQTT_H
#define DHTLedMQTT_H

#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <ArduinoJson.h>

class DHTLedMQTT {
public:
    DHTLedMQTT(const char* ssid, const char* pass, const char* mqttServer, int mqttPort, const char* clientID, int dhtPin, int ledPin);

    void start();
    void run();
    void callback(char* topic, byte* message, unsigned int length);

private:
    const char* _ssid;
    const char* _pass;
    const char* _mqttServer;
    int _mqttPort;
    const char* _clientID;
    int _dhtPin;
    int _ledPin;

    DHT* _dht;

    unsigned long _lastSentTime = 0;
    const unsigned long _interval = 5000;

    WiFiClient _espClient;
    PubSubClient _mqttClient;

    void reconnect();
};

#endif
