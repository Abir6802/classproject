#include "DHTLedMQTT.h"

DHTLedMQTT::DHTLedMQTT(const char* ssid, const char* pass, const char* mqttServer, int mqttPort, const char* clientID, int dhtPin, int ledPin)
  : _ssid(ssid), _pass(pass), _mqttServer(mqttServer), _mqttPort(mqttPort), _clientID(clientID), _dhtPin(dhtPin), _ledPin(ledPin),
    _mqttClient(_espClient)
{
    _dht = new DHT(_dhtPin, DHT22);
}

void DHTLedMQTT::start() {
    Serial.begin(9600);
    _dht->begin();

    pinMode(_ledPin, OUTPUT);
    digitalWrite(_ledPin, HIGH);
    WiFi.begin(_ssid, _pass);
    while (WiFi.status() != WL_CONNECTED) {
        delay(250);
        Serial.print(".");
    }
    Serial.println("WiFi Connected");

    _mqttClient.setServer(_mqttServer, _mqttPort);
    _mqttClient.setCallback([this](char* topic, byte* message, unsigned int length) {
        this->callback(topic, message, length);
    });
}

void DHTLedMQTT::reconnect() {
    while (!_mqttClient.connected()) {
        Serial.print("Attempting MQTT connection...");
        if (_mqttClient.connect(_clientID)) {
            Serial.println("connected");
            _mqttClient.subscribe("/68071af195326f0d8de98c38/68071bf2b173ede64c1a9034/led_red");
        } else {
            Serial.print("failed, rc=");
            Serial.print(_mqttClient.state());
            Serial.println(" try again in 5 seconds");
            delay(5000);
        }
    }
}

void DHTLedMQTT::run() {
    if (!_mqttClient.connected()) {
        reconnect();
    }
    _mqttClient.loop();

    unsigned long currentTime = millis();
    if (currentTime - _lastSentTime >= _interval) {
        _lastSentTime = currentTime;

        float humi = _dht->readHumidity();
        float temp = _dht->readTemperature();
        bool ledState = (digitalRead(_ledPin) == LOW);

        StaticJsonDocument<200> doc;
        doc["temperature"] = temp;
        doc["humidity"] = humi;
        doc["led_red"] = ledState;

        char buffer[150];
        serializeJson(doc, buffer);

        _mqttClient.publish("/68071af195326f0d8de98c38/68071bf2b173ede64c1a9034/data", buffer);

        Serial.println("Data published");
    }
}

void DHTLedMQTT::callback(char* topic, byte* message, unsigned int length) {
    char jsonStr[100];
    if (length < sizeof(jsonStr)) {
        memcpy(jsonStr, message, length);
        jsonStr[length] = '\0';

        StaticJsonDocument<200> doc;
        DeserializationError error = deserializeJson(doc, jsonStr);

        if (!error) {
            if (doc.containsKey("led_red")) {
                bool ledState = doc["led_red"];
                digitalWrite(_ledPin, ledState ? LOW : HIGH);
                Serial.println(ledState ? "LED ON" : "LED OFF");
            }
        } else {
            Serial.println("JSON parsing failed");
        }
    }
}
